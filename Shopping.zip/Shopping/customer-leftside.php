<html>
<body>
<!-- sidebar start -->
  <div class="admin-sidebar am-offcanvas" id="admin-offcanvas">
    <div class="am-offcanvas-bar admin-offcanvas-bar">
      <ul class="am-list admin-sidebar-list">
        <li class="admin-parent">
          <a class="am-cf" data-am-collapse="{target: '#collapse-nav'}"><span class="am-icon-file"></span>Customer<span class="am-icon-angle-right am-fr am-margin-right"></span></a>
          <ul class="am-list am-collapse admin-sidebar-sub am-in" id="collapse-nav">
            <li><a href="customer-instructions.php"><span class="am-icon-puzzle-piece"></span>Instructions</a></li>
            
            <li><a href="customer-products.php"><span class="am-icon-th"></span>Products</a></li>
            
            <li><a href="customer-transaction.php"><span class="am-icon-table"></span>Transaction</a></li>
          </ul>
        </li>       
      </ul>
      <div class="am-panel am-panel-default admin-sidebar-panel">
        <div class="am-panel-bd">
          <p><span class="am-icon-tag"></span> wiki</p>
          <p>Welcome to the Amaze UI wiki!</p>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
  <!-- sidebar end -->