<html>
<body>
<!-- sidebar start -->
  <div class="admin-sidebar am-offcanvas" id="admin-offcanvas">
    <div class="am-offcanvas-bar admin-offcanvas-bar">
      <ul class="am-list admin-sidebar-list">
        <li><a><span class="am-icon-home"></span>Back End</a></li>
        <li class="admin-parent">
          <a class="am-cf" data-am-collapse="{target: '#collapse-nav'}"><span class="am-icon-file"></span> Manager <span class="am-icon-angle-right am-fr am-margin-right"></span></a>
          <ul class="am-list am-collapse admin-sidebar-sub am-in" id="collapse-nav">
            <li><a href="admin-instructions.php"><span class="am-icon-puzzle-piece"></span>Instructions</a></li>
            
            <li><a href="admin-customer_management.php"><span class="am-icon-calendar"></span> Customer Management</a></li>
            <li><a href="admin-products.php"><span class="am-icon-th"></span> Products</a></li>
            
            <li><a href="admin-transaction.php"><span class="am-icon-table"></span> Transaction Management </a></li>
            <li><a href="admin-salesman.php"><span class="am-icon-table"></span> Employee</a></li>
            <li><a href="admin-store.php"><span class="am-icon-table"></span> Real Stores</a></li>
            <li><a href="admin-supplier.php"><span class="am-icon-table"></span> Suppliers</a></li>
            <li><a href="viz.php"><span class="am-icon-table"></span> Visualization </a></li>
          </ul>
        </li>       
      </ul>
      <div class="am-panel am-panel-default admin-sidebar-panel">
        <div class="am-panel-bd">
          <p><span class="am-icon-tag"></span> wiki</p>
          <p>Welcome to the Amaze UI wiki!</p>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
  <!-- sidebar end -->